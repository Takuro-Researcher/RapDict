package com.rapdict.takuro.rapdict

class Answer {
    var answer_id: Int = 0
    var question_id: Int = 0
    var answer: String? = null
}
