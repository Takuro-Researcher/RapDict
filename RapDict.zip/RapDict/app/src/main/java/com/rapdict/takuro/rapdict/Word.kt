package com.rapdict.takuro.rapdict

 class Word {
    var word_id: Int ?= null
    var furigana: String ?=null
    var word: String ?=null
    var word_len: Int ?=null
}
